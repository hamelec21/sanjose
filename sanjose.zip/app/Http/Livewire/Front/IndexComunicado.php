<?php

namespace App\Http\Livewire\Front;

use App\Models\Comunicado;
use Livewire\Component;

class IndexComunicado extends Component
{
    public function render()
    {
        $comunicados = Comunicado::first();
        return view('livewire.front.index-comunicado',compact('comunicados'));
    }
}
