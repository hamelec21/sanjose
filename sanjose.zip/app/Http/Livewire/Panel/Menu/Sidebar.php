<?php

namespace App\Http\Livewire\Panel\Menu;

use Livewire\Component;

class Sidebar extends Component
{
    public function render()
    {
        return view('livewire.panel.menu.sidebar');
    }
}
