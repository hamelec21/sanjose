<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('panel.menu.sidebar')->html();
} elseif ($_instance->childHasBeenRendered('c6q9RKX')) {
    $componentId = $_instance->getRenderedChildComponentId('c6q9RKX');
    $componentTag = $_instance->getRenderedChildComponentTagName('c6q9RKX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('c6q9RKX');
} else {
    $response = \Livewire\Livewire::mount('panel.menu.sidebar');
    $html = $response->html();
    $_instance->logRenderedChild('c6q9RKX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="ml-auto mb-6 lg:w-[75%] xl:w-[80] 2xl:w-[85%]">

        <!--Header-->

        <?php echo $__env->make('header-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="w-full pt-6 text-xl text-center">DASHBOARD</div>
        <!-- section card one -->
        <br>
        <div class="container py-10 mx-auto ">
            <div class="grid grid-cols-1 gap-4 mx-4 my-2  lg:grid-cols-6">
                <div class="h-40 p-6 text-center text-gray-300 bg-sidebar rounded-lg shadow-xl hover:bg-gray-800">
                    <i class="text-jr fas fa-university fa-2x"></i>
                    <div class="pt-8  text-dev">
                        <a href="/admision/crear-admision">Crear Comunicado</a>
                    </div>
                </div>

                <div class="h-40 p-6 text-center text-gray-300 bg-sidebar rounded-lg shadow-xl hover:bg-gray-800">
                    <i class="text-jr fas fa-university fa-2x"></i>
                    <i class="fa-duotone fa-newspaper"></i>
                    <div class="pt-8  text-dev">
                        <a href="/admision/crear-admision">Crear Noticia</a>
                    </div>
                </div>

                <div class="h-40 p-6 text-center text-gray-300 bg-sidebar rounded-lg shadow-xl hover:bg-gray-800">
                    <i class="text-jr fas fa-university fa-2x"></i>
                    <div class="pt-8  text-dev">
                        <a href="/admision/crear-admision">Crear Admisión</a>
                    </div>
                </div>

                <div class="h-40 p-6 text-center text-gray-300 bg-sidebar rounded-lg shadow-xl hover:bg-gray-800">
                    <i class="text-jr fas fa-university fa-2x"></i>
                    <div class="pt-8  text-dev">
                        <a href="/admision/crear-admision">Crear Admisión</a>
                    </div>
                </div>

                <div class="h-40 p-6 text-center text-gray-300 bg-sidebar rounded-lg shadow-xl hover:bg-gray-800">
                    <i class="text-jr fas fa-university fa-2x"></i>
                    <div class="pt-8  text-dev">
                        <a href="/admision/crear-admision">Crear Admisión</a>
                    </div>
                </div>

                <div class="h-40 p-6 text-center text-gray-300 bg-sidebar rounded-lg shadow-xl hover:bg-gray-800">
                    <i class="text-jr fas fa-university fa-2x"></i>
                    <div class="pt-8  text-dev">
                        <a href="/admision/crear-admision">Crear Admisión</a>
                    </div>
                </div>
            </div>
        </div>


    </div>


    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH F:\laragon\www\LARAVEL_V10\sanjose\resources\views/dashboard.blade.php ENDPATH**/ ?>