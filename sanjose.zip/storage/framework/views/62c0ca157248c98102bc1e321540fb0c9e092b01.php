<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('panel.menu.sidebar')->html();
} elseif ($_instance->childHasBeenRendered('l4185795393-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4185795393-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4185795393-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4185795393-0');
} else {
    $response = \Livewire\Livewire::mount('panel.menu.sidebar');
    $html = $response->html();
    $_instance->logRenderedChild('l4185795393-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    <div class="ml-auto mb-6 lg:w-[75%] xl:w-[80] 2xl:w-[85%] ">
        
        <div class="overflow-x-auto">
            <div class="mt-10 flex items-center justify-center bg-gray-100 font-sans overflow-hidden">
                <div class="w-full lg:w-5/6">
                    

                    <div class="container mx-auto">
                        <div class="text-gray-100 text-center mt-10 text-lg font-bold uppercase bg-encabezado py-1">Noticias</div>
                    </div>
                      <div class="flex justify-around bg-gray-200">

                        <div class=" text-left text-gray-900 font-bold py-1 text-sm mt-2">

                            <input wire:model.live="search" type="text" name="titulo" id="" placeholder="Busqueda"
                                class=" rounded-lg border-transparent flex-1 appearance-none border border-blue-600 w-full py-1 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent">
                            <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error text-red-600 text-xs"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <a href="<?php echo e(route('crear-noticia')); ?>">
                        <button class="btn-agregar mb-5 mt-3">Crear Nueva noticia</button>
                        </a>
                    </div>

                    <div class="bg-white shadow-md rounded my-6">

                        <table class="min-w-max w-full table-auto">

                            <thead>
                                <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                                    <th class="py-3 px-6 text-left">Fotografia</th>
                                    <th class="py-3 px-6 text-left">Noticia</th>
                                    <th class="py-3 px-6 text-left">fecha</th>
                                    <th class="py-3 px-6 text-center">Acciones</th>
                                </tr>
                            </thead>
                            <?php if($news->count()): ?>
                                <tbody class="text-gray-600 text-sm font-light">
                                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="border-b border-gray-200 hover:bg-gray-100">
                                            <td class="py-3 px-6 text-left whitespace-nowrap">
                                                <div class="flex items-center">
                                                    <div class="mr-2">
                                                        <span class="font-medium"><img
                                                                src="<?php echo e(Storage::url($new->imagen)); ?>"
                                                                class=" w-20" /></span>
                                                    </div>

                                                </div>
                                            </td>
                                            <td class="py-3 px-6 text-center">
                                                <div class="flex items-center font-bold">
                                                    <span> <?php echo e($new->titulo); ?></span>
                                                </div>
                                            </td>

                                            <td class="py-3 px-6 text-left">
                                                <div class="flex items-center">
                                                    <span> <?php echo e(date('d-m-Y', strtotime($new->created_at))); ?></span>
                                                </div>
                                            </td>

                                            <td class="py-3 px-6 text-center">
                                                <div class="flex item-center justify-center">

                                                    <div class="flex items-center justify-around py-2 ">
                                                        

                                                        <a href="<?php echo e(route('editar-noticia',[$new->id])); ?>">
                                                            <button class="btn-editar mb-5">Editar</button>
                                                            </a>

                                                    </div>


                                                    <div class="mt-2 px-3">
                                                        <a onclick="confirm('Estas Seguro de Eliminar La Noticia !')||event.stopImmediatePropagation()"
                                                            wire:click="destroy(<?php echo e($new->id); ?>)"><button
                                                                class="btn btn-eliminar ">Eliminar</button> </a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                        </table>
                    <?php else: ?>
                        <?php echo $__env->make('components.alerta-busqueda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                        <div class="bg-gray-200">
                            <?php if($news->hasPages()): ?>
                                <div class="px-6 py-3 ">
                                    <?php echo e($news->links()); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>

<?php /**PATH F:\laragon\www\LARAVEL_V10\sanjose\resources\views/livewire/panel/noticia/show-noticia.blade.php ENDPATH**/ ?>