<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Escuela San jose</title>

        <!-- Fonts -->
        <link href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
         <?php echo \Livewire\Livewire::styles(); ?>

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body>
         <!--menu principal-->

<?php echo $__env->make('menu_principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--conponnete de livewire-->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.show-noticias')->html();
} elseif ($_instance->childHasBeenRendered('wuLzZ9i')) {
    $componentId = $_instance->getRenderedChildComponentId('wuLzZ9i');
    $componentTag = $_instance->getRenderedChildComponentTagName('wuLzZ9i');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wuLzZ9i');
} else {
    $response = \Livewire\Livewire::mount('front.show-noticias');
    $html = $response->html();
    $_instance->logRenderedChild('wuLzZ9i', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<!--fin de Contenido page-->
<br><br><br><br><br><br><br>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.4/flowbite.min.js"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>

<?php /**PATH F:\laragon\www\LARAVEL_V10\sanjose\resources\views/noticias.blade.php ENDPATH**/ ?>