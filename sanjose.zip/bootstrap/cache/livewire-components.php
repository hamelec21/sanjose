<?php return array (
  'front.index-comunicado' => 'App\\Http\\Livewire\\Front\\IndexComunicado',
  'front.index-resumen-noticias' => 'App\\Http\\Livewire\\Front\\IndexResumenNoticias',
  'front.show-articulo-noticia' => 'App\\Http\\Livewire\\Front\\ShowArticuloNoticia',
  'front.show-noticias' => 'App\\Http\\Livewire\\Front\\ShowNoticias',
  'panel.comunicado.crear-comunicado' => 'App\\Http\\Livewire\\Panel\\Comunicado\\CrearComunicado',
  'panel.comunicado.editar-comunicado' => 'App\\Http\\Livewire\\Panel\\Comunicado\\EditarComunicado',
  'panel.comunicado.show-comunicado' => 'App\\Http\\Livewire\\Panel\\Comunicado\\ShowComunicado',
  'panel.menu.sidebar' => 'App\\Http\\Livewire\\Panel\\Menu\\Sidebar',
  'panel.noticia.crear-noticia' => 'App\\Http\\Livewire\\Panel\\Noticia\\CrearNoticia',
  'panel.noticia.editar-noticia' => 'App\\Http\\Livewire\\Panel\\Noticia\\EditarNoticia',
  'panel.noticia.show-noticia' => 'App\\Http\\Livewire\\Panel\\Noticia\\ShowNoticia',
);